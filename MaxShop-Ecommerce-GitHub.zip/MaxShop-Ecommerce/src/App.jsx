import { useMemo, useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import CategoryFilter from './components/CategoryFilter';
import ProductList from './components/ProductList';
import TopProducts from './components/TopProducts';
import Testimonials from './components/Testimonials';
import Subscribe from './components/Subscribe';
import Cart from './components/Cart';
import { CartProvider } from './context/CartContext';
import useCart from './hooks/useCart';
import { products } from './data/products';

function Store() {
  const cart = useCart();
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [cartOpen, setCartOpen] = useState(false);

  const filteredProducts = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();
    return products.filter((product) => {
      const categoryMatch = selectedCategory === 'All' || product.category === selectedCategory;
      const searchMatch = !query || `${product.name} ${product.description}`.toLowerCase().includes(query);
      return categoryMatch && searchMatch;
    });
  }, [searchTerm, selectedCategory]);

  const scrollToShop = () => document.getElementById('shop')?.scrollIntoView({ behavior: 'smooth' });

  return (
    <CartProvider value={cart}>
      <Navbar searchTerm={searchTerm} setSearchTerm={setSearchTerm} onOpenCart={() => setCartOpen(true)} />
      <Hero onShopNow={scrollToShop} />
      <section id="shop" className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mb-8 flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="text-sm font-bold uppercase tracking-widest text-primary">Browse collection</p>
            <h2 className="mt-2 text-3xl font-black">Find something you will use</h2>
          </div>
          <CategoryFilter selected={selectedCategory} onSelect={setSelectedCategory} />
        </div>
        <ProductList products={filteredProducts} />
      </section>
      <TopProducts products={products} />
      <Testimonials />
      <Subscribe />
      <footer className="border-t border-slate-200 py-8 text-center text-sm text-slate-500 dark:border-slate-800">
        © {new Date().getFullYear()} MaxShop. Built as a frontend project.
      </footer>
      <Cart open={cartOpen} onClose={() => setCartOpen(false)} />
    </CartProvider>
  );
}

export default Store;
