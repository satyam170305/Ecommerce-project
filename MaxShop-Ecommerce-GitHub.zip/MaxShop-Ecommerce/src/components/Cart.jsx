import { Minus, Plus, Trash2, X } from 'lucide-react';
import { useCartContext } from '../context/CartContext';

const money = (value) => `₹${value.toLocaleString('en-IN')}`;

export default function Cart({ open, onClose }) {
  const { items, removeFromCart, updateQuantity, clearCart, totalPrice } = useCartContext();
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50">
      <button className="absolute inset-0 bg-slate-950/50" onClick={onClose} aria-label="Close cart" />
      <aside className="absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-white shadow-2xl dark:bg-slate-900">
        <div className="flex items-center justify-between border-b border-slate-200 p-5 dark:border-slate-800">
          <div>
            <h2 className="text-xl font-black">Your cart</h2>
            <p className="text-sm text-slate-500">{items.length} product type(s)</p>
          </div>
          <button onClick={onClose} className="rounded-full p-2 hover:bg-slate-100 dark:hover:bg-slate-800" aria-label="Close">
            <X size={20} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5">
          {!items.length ? (
            <div className="py-20 text-center text-slate-500">Your cart is empty.</div>
          ) : (
            <div className="space-y-4">
              {items.map((item) => (
                <div key={item.id} className="flex gap-3 rounded-2xl border border-slate-200 p-3 dark:border-slate-800">
                  <img src={item.image} alt={item.name} className="h-20 w-20 rounded-xl bg-slate-100 object-cover dark:bg-slate-800" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="truncate font-bold">{item.name}</h3>
                        <p className="text-sm text-slate-500">{money(item.price)}</p>
                      </div>
                      <button onClick={() => removeFromCart(item.id)} className="p-1 text-slate-400 hover:text-red-500" aria-label={`Remove ${item.name}`}>
                        <Trash2 size={16} />
                      </button>
                    </div>
                    <div className="mt-3 inline-flex items-center rounded-full border border-slate-200 dark:border-slate-700">
                      <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="p-2"><Minus size={14} /></button>
                      <span className="w-8 text-center text-sm font-bold">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="p-2"><Plus size={14} /></button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="border-t border-slate-200 p-5 dark:border-slate-800">
          <div className="flex items-center justify-between text-lg font-black">
            <span>Total</span>
            <span>{money(totalPrice)}</span>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <button onClick={clearCart} disabled={!items.length} className="rounded-xl border border-slate-200 py-3 text-sm font-bold disabled:opacity-40 dark:border-slate-700">Clear</button>
            <button disabled={!items.length} className="rounded-xl bg-primary py-3 text-sm font-bold text-white disabled:opacity-40">Checkout</button>
          </div>
        </div>
      </aside>
    </div>
  );
}
