import { Moon, Sun } from 'lucide-react';
import { useEffect, useState } from 'react';

export default function DarkMode() {
  const [dark, setDark] = useState(() => localStorage.getItem('maxshop-theme') === 'dark');

  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark);
    localStorage.setItem('maxshop-theme', dark ? 'dark' : 'light');
  }, [dark]);

  return (
    <button
      onClick={() => setDark((value) => !value)}
      aria-label="Toggle dark mode"
      className="rounded-full border border-slate-200 bg-white p-2 text-slate-700 transition hover:scale-105 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
    >
      {dark ? <Sun size={18} /> : <Moon size={18} />}
    </button>
  );
}
