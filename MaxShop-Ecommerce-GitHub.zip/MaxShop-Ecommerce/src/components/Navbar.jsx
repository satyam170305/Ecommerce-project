import { Search, ShoppingBag, Menu, X } from 'lucide-react';
import { useState } from 'react';
import DarkMode from './DarkMode';
import { useCartContext } from '../context/CartContext';

export default function Navbar({ searchTerm, setSearchTerm, onOpenCart }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const { totalItems } = useCartContext();

  return (
    <nav className="sticky top-0 z-40 border-b border-slate-200 bg-white/95 backdrop-blur dark:border-slate-800 dark:bg-slate-900/95">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 sm:px-6 lg:px-8">
        <a href="#home" className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white">
          Max<span className="text-primary">Shop</span>
        </a>

        <div className="hidden flex-1 items-center justify-center gap-6 md:flex">
          <a href="#home" className="text-sm font-medium hover:text-primary">Home</a>
          <a href="#shop" className="text-sm font-medium hover:text-primary">Shop</a>
          <a href="#about" className="text-sm font-medium hover:text-primary">About</a>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative hidden sm:block">
            <input
              type="text"
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
              placeholder="Search products"
              className="w-44 rounded-full border border-slate-200 bg-slate-50 py-2 pl-4 pr-9 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-blue-100 dark:border-slate-700 dark:bg-slate-800 dark:focus:ring-slate-700"
            />
            <Search size={17} className="absolute right-3 top-2.5 text-slate-400" />
          </div>
          <DarkMode />
          <button
            onClick={onOpenCart}
            className="relative rounded-full border border-slate-200 bg-white p-2 text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
            aria-label="Open shopping cart"
          >
            <ShoppingBag size={19} />
            {totalItems > 0 && (
              <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-white">
                {totalItems}
              </span>
            )}
          </button>
          <button
            onClick={() => setMenuOpen((value) => !value)}
            className="rounded-full border border-slate-200 p-2 md:hidden dark:border-slate-700"
            aria-label="Toggle menu"
          >
            {menuOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {menuOpen && (
        <div className="border-t border-slate-200 px-4 py-3 md:hidden dark:border-slate-800">
          <div className="flex flex-col gap-3">
            <a href="#home" onClick={() => setMenuOpen(false)}>Home</a>
            <a href="#shop" onClick={() => setMenuOpen(false)}>Shop</a>
            <a href="#about" onClick={() => setMenuOpen(false)}>About</a>
            <div className="relative sm:hidden">
              <input
                type="text"
                value={searchTerm}
                onChange={(event) => setSearchTerm(event.target.value)}
                placeholder="Search products"
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 pl-4 pr-9 text-sm outline-none dark:border-slate-700 dark:bg-slate-800"
              />
              <Search size={17} className="absolute right-3 top-2.5 text-slate-400" />
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
