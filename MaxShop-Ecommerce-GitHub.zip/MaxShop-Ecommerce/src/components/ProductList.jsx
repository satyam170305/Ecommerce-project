import ProductCard from './ProductCard';

export default function ProductList({ products }) {
  if (!products.length) {
    return (
      <div className="rounded-2xl border border-dashed border-slate-300 p-10 text-center dark:border-slate-700">
        <p className="font-semibold">No products found.</p>
        <p className="mt-1 text-sm text-slate-500">Try another search or category.</p>
      </div>
    );
  }

  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {products.map((product) => <ProductCard key={product.id} product={product} />)}
    </div>
  );
}
