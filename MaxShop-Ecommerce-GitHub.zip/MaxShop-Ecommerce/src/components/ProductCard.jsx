import { ShoppingBag, Star } from 'lucide-react';
import { useCartContext } from '../context/CartContext';

const money = (value) => `₹${value.toLocaleString('en-IN')}`;

export default function ProductCard({ product }) {
  const { addToCart } = useCartContext();

  return (
    <article className="group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900">
      <div className="aspect-[4/3] overflow-hidden bg-slate-100 dark:bg-slate-800">
        <img src={product.image} alt={product.name} className="h-full w-full object-cover transition duration-300 group-hover:scale-105" />
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">{product.category}</span>
          <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-500">
            <Star size={13} fill="currentColor" /> {product.rating}
          </span>
        </div>
        <h3 className="mt-2 font-bold text-slate-900 dark:text-white">{product.name}</h3>
        <p className="mt-1 line-clamp-2 text-sm leading-5 text-slate-500 dark:text-slate-400">{product.description}</p>
        <div className="mt-4 flex items-center justify-between gap-3">
          <span className="text-lg font-extrabold">{money(product.price)}</span>
          <button
            onClick={() => addToCart(product)}
            disabled={!product.inStock}
            className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-sm font-bold text-white transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:bg-slate-400"
          >
            <ShoppingBag size={16} /> Add
          </button>
        </div>
      </div>
    </article>
  );
}
