import { useState } from 'react';

export default function Subscribe() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <section id="about" className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
      <div className="rounded-3xl bg-gradient-to-r from-primary to-secondary p-8 text-white md:p-12">
        <div className="grid gap-8 md:grid-cols-2 md:items-center">
          <div>
            <h2 className="text-3xl font-black">Stay in the loop</h2>
            <p className="mt-3 max-w-xl text-white/80">Get occasional updates about new products and offers.</p>
          </div>
          <form onSubmit={handleSubmit} className="flex gap-2 rounded-2xl bg-white/10 p-2 backdrop-blur">
            <input
              required
              type="email"
              placeholder="Email address"
              className="min-w-0 flex-1 bg-transparent px-3 py-2 text-sm outline-none placeholder:text-white/60"
            />
            <button className="rounded-xl bg-white px-4 py-2 text-sm font-bold text-slate-900">Subscribe</button>
          </form>
        </div>
        {submitted && <p className="mt-4 text-sm text-white/90">Thanks! You are on the list.</p>}
      </div>
    </section>
  );
}
