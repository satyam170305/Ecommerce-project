import { ArrowRight, Sparkles } from 'lucide-react';

export default function Hero({ onShopNow }) {
  return (
    <section id="home" className="relative overflow-hidden bg-slate-900 text-white">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_rgba(37,99,235,0.28),_transparent_35%),radial-gradient(circle_at_bottom_left,_rgba(124,58,237,0.22),_transparent_35%)]" />
      <div className="relative mx-auto grid max-w-7xl gap-10 px-4 py-20 sm:px-6 md:grid-cols-2 md:items-center lg:px-8 lg:py-28">
        <div>
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-3 py-1 text-xs font-semibold">
            <Sparkles size={14} /> Fresh arrivals
          </div>
          <h1 className="max-w-2xl text-4xl font-black leading-tight sm:text-5xl lg:text-6xl">
            Everyday style, made simple.
          </h1>
          <p className="mt-5 max-w-xl text-base leading-7 text-slate-300 sm:text-lg">
            Discover useful, comfortable products for work, weekends and everything in between.
          </p>
          <button
            onClick={onShopNow}
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 font-bold text-slate-900 transition hover:-translate-y-0.5"
          >
            Shop now <ArrowRight size={18} />
          </button>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {[
            ['50%', 'Selected styles'],
            ['24/7', 'Online shopping'],
            ['8+', 'Curated products'],
            ['4.6/5', 'Average rating']
          ].map(([value, label]) => (
            <div key={label} className="rounded-3xl border border-white/10 bg-white/10 p-6 backdrop-blur">
              <div className="text-3xl font-extrabold">{value}</div>
              <div className="mt-2 text-sm text-slate-300">{label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
