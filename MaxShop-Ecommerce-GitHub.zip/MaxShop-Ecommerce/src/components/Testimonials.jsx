const testimonials = [
  { name: 'Riya', role: 'Student', text: 'The layout is clean and the cart is easy to use.' },
  { name: 'Arjun', role: 'Designer', text: 'Search and category filtering make product discovery quick.' },
  { name: 'Neha', role: 'Developer', text: 'The responsive layout feels consistent across screen sizes.' }
];

export default function Testimonials() {
  return (
    <section className="bg-slate-100 py-16 dark:bg-slate-950">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p className="text-sm font-bold uppercase tracking-widest text-primary">What users say</p>
          <h2 className="mt-2 text-3xl font-black">Simple shopping experience</h2>
        </div>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {testimonials.map((item) => (
            <blockquote key={item.name} className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <p className="leading-7 text-slate-600 dark:text-slate-300">“{item.text}”</p>
              <footer className="mt-5">
                <div className="font-bold">{item.name}</div>
                <div className="text-sm text-slate-500">{item.role}</div>
              </footer>
            </blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}
