import ProductCard from './ProductCard';

export default function TopProducts({ products }) {
  return (
    <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
      <div className="mb-8 flex items-end justify-between gap-4">
        <div>
          <p className="text-sm font-bold uppercase tracking-widest text-primary">Popular picks</p>
          <h2 className="mt-2 text-3xl font-black">Top products</h2>
        </div>
        <a href="#shop" className="text-sm font-bold text-primary">View all</a>
      </div>
      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
        {products.slice(0, 4).map((product) => <ProductCard key={product.id} product={product} />)}
      </div>
    </section>
  );
}
