export const products = [
  {
    id: 1,
    name: 'Classic Denim Jacket',
    price: 1799,
    category: 'Men',
    image: '/images/jacket.svg',
    description: 'Everyday denim jacket with a comfortable regular fit.',
    rating: 4.6,
    inStock: true
  },
  {
    id: 2,
    name: 'Urban Sneakers',
    price: 2299,
    category: 'Shoes',
    image: '/images/sneakers.svg',
    description: 'Lightweight sneakers designed for daily city walks.',
    rating: 4.8,
    inStock: true
  },
  {
    id: 3,
    name: 'Minimal Tote Bag',
    price: 999,
    category: 'Accessories',
    image: '/images/bag.svg',
    description: 'Simple carry-all bag with a roomy main compartment.',
    rating: 4.4,
    inStock: true
  },
  {
    id: 4,
    name: 'Everyday Hoodie',
    price: 1499,
    category: 'Men',
    image: '/images/hoodie.svg',
    description: 'Soft fleece hoodie made for relaxed everyday wear.',
    rating: 4.7,
    inStock: true
  },
  {
    id: 5,
    name: 'Relaxed Linen Shirt',
    price: 1299,
    category: 'Women',
    image: '/images/shirt.svg',
    description: 'Breathable linen shirt with a clean relaxed silhouette.',
    rating: 4.5,
    inStock: true
  },
  {
    id: 6,
    name: 'Everyday Watch',
    price: 2499,
    category: 'Accessories',
    image: '/images/watch.svg',
    description: 'Clean dial, durable strap and a classic everyday profile.',
    rating: 4.3,
    inStock: true
  },
  {
    id: 7,
    name: 'Canvas Trainers',
    price: 1699,
    category: 'Shoes',
    image: '/images/trainers.svg',
    description: 'Casual canvas shoes with a flexible rubber sole.',
    rating: 4.2,
    inStock: true
  },
  {
    id: 8,
    name: 'Soft Knit Sweater',
    price: 1899,
    category: 'Women',
    image: '/images/sweater.svg',
    description: 'Warm knit sweater with a simple modern finish.',
    rating: 4.6,
    inStock: true
  }
];

export const categories = ['All', 'Men', 'Women', 'Shoes', 'Accessories'];
