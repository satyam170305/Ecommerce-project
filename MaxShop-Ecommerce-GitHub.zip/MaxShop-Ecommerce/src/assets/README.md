Local project assets can be placed here when the site is customized with a real logo or imported images.
