# MaxShop - E-Commerce Website

A responsive e-commerce frontend built with React, Tailwind CSS and JavaScript ES6+.

## Features

- Product grid with category filtering
- Case-insensitive search by product name and description
- Add, remove and update cart quantities
- Cart persistence with `localStorage`
- Light/dark theme toggle
- Responsive navigation and layout
- Reusable React components

## Tech stack

- React 18
- Tailwind CSS 3
- JavaScript ES6+
- Create React App
- Lucide React icons

## Run locally

```bash
npm install
npm start
```

The app opens at `http://localhost:3000`.

## Build

```bash
npm run build
```
